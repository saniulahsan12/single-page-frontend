1. Used google api fonts so internet connection is required i think.
2. Used open sans and nunito as asked, but i think the design layout fonts are little bit different.
3. Tried to make the layout as in image provided but i have also tried the other i devices to look the design better.
4. All tested i have used on emulator as i have no i devices.
5. There was no hover effect suggestions or any animation suggestions. So i have used all on my own.
6. Thanks